This is my first Full stack web development of a ECommerce site using Django Framework, html , css and Javascript with sqlite database.
I have added a cart system to add items to a cart,
Checkout page which will display the final products added in the cart along with the total price of all the items in the cart
and finally i have added the paytm API to transfer the user to the paytm payment page to pay for the purchased items
